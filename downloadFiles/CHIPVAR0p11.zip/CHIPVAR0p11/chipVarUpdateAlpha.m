function alpha=chipVarUpdateAlpha(expectationsB)

% CHIPVARUPDATEALPHA updates alpha in E-M
%
%	Description:
%	alpha=chipVarUpdateAlpha(expectationsB)
%

%	Copyright (c) 2007 , 2006, Guido Sanguinetti
% 	chipVarUpdateAlpha.m version 1.1

nGenes=size(expectationsB.b,1);
nTrans=size(expectationsB.b,2);
alpha=nGenes*nTrans/trace(expectationsB.bbTotal);