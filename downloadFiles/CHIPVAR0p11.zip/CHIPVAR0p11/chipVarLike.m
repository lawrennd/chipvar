function f=chipVarLike(Gamma,data,X,alpha,beta,...
                       expectationsB,expectationsC)

% CHIPVARLIKE likelihood for chipVar to optimise Gamma and m
%
%	Description:
%	f=chipVarLike(Gamma,data,X,alpha,beta,...
%                       expectationsB,expectationsC)
%

%	Copyright (c) 2007 , 2006, Guido Sanguinetti
% 	chipVarLike.m version 1.1

nTrans=size(X,2);
model.Gamma=Gamma';
model.alpha=alpha;
model.beta=beta;
f=-chipVarLikelihoodBound(model,data,X,expectationsC, expectationsB);