function [geneName, annotation, data] = chipChipTextRead(file1, file2)

% CHIPCHIPTEXTREAD reads TXT file for the Lee ChIP data files.
%
%	Description:
%	[geneName, annotation, data] = chipChipTextRead(file1, file2)
%

%	Copyright (c) 2007 , 2006, Guido Sanguinetti
% 	chipChipTextRead.m version 1.2

[geneName,annotation]=...
    textread(file1,'%q %q %*[^\n]',...
    'headerlines',2,'whitespace','','delimiter','\t');

data = load(file2);