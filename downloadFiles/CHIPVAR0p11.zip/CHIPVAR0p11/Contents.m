% CHIPVAR toolbox
% Version 0.11		Saturday 06 Jan 2007 at 11:28
% Copyright (c) 2007 , 2006, Guido Sanguinetti
% 
% CHIPVAREMMU E-M algorithm for dynamical network analysis
% CHIPCHIPTEXTREAD reads TXT file for the Lee ChIP data files.
% CHIPVARREDLOADDATA loads reduced Spellman Data with Lee et al ChIP data.
% CHIPVARINIT initialises E-M algorithm
% CHIPVARLIKE likelihood for chipVar to optimise Gamma and m
% CHIPVARUPDATEBETAMU updates the precision in E-M algorithm
% CHIPVAREM E-M algorithm for dynamical network analysis
% DEMSPELLMANVAR demonstrates chipVar on Spellman
% CHIPVARFAKEDATA artificial data for checking chipVar
% CHIPTEXTREAD reads TXT file for the Spellman data files.
% CHIPVARESTEPB variational update of the expectations of b
% CHIPVARESTEPC variational update of C
% CHIPVARLIKEGAMMA one dimensional gamma likelihood
% CHIPVARESTEPBMU variational update of the expectations of b
% CHIPVARLIKELIHOODBOUND variational lower bound on marginal likelihood
% CHIPVARESTEPCMU variational update of expectations of C.
% CHIPVARLIKEGRAD gradient of chipVarLike
% CHIPVARLIKELIHOODCHECK Compute the difference in likelhoods.
% CHIPVARTULOADDATA loads metabolic Data with combined ChIP data.
% CHIPVARESTEP variational E-step for chipVar
% CHIPVARUPDATEALPHA updates alpha in E-M
% CHIPTUTEXTREAD assigns common names to probe IDs
% CHIPVARLIKELIHOODCHECKMU Compute the difference in likelhoods.
% CHIPVARUPDATEBETA updates the precision in E-M algorithm
% CHIPVARESTEPMUMU variational update of mu
% CHIPVAROPTIONS sets default options for chipVar
% CHIPVARLIKELIHOODBOUNDMU variational lower bound on marginal likelihood
% CHIPVARESTEPMU variational E-step for chipVar
% CHIPVARLIKEGAMMAGRAD gradient of chipVarLikeGamma
% DEMTUVAR demonstrates chipVar on metabolic data
% DEMFAKEVAR demonstrates chipVar on artificial data
