function options=chipVarOptions()

% CHIPVAROPTIONS sets default options for chipVar
%
%	Description:
%	options=chipVarOptions()
%

%	Copyright (c) 2007 , 2006, Guido Sanguinetti
% 	chipVarOptions.m version 1.1

options.tol=1e-4;
options.maxIters=1500;
options.tolEstep=1e-4;
options.stepChecks=0;
options.optimizer=foptions;