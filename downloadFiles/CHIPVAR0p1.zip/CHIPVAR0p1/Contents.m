% CHIPVAR toolbox
% Version 0.1		Monday 22 May 2006 at 21:51
% Copyright (c) 2006 Neil D. Lawrence
% 
% CHIPCHIPTEXTREAD reads TXT file for the Lee ChIP data files.
% CHIPTEXTREAD reads TXT file for the Spellman data files.
% CHIPTUTEXTREAD assigns common names to probe IDs
% CHIPVAREM E-M algorithm for dynamical network analysis
% CHIPVAREMMU E-M algorithm for dynamical network analysis
% CHIPVARESTEPB variational update of the expectations of b
% CHIPVARESTEPBMU variational update of the expectations of b
% CHIPVARESTEPC variational update of C
% CHIPVARESTEP variational E-step for chipVar
% CHIPVARESTEPMU variational E-step for chipVar
% CHIPVARESTEPMUMU variational update of mu
% CHIPVARFAKEDATA artificial data for checking chipVar
% CHIPVARINIT initialises E-M algorithm
% DEMTUVAR demonstrates chipVar on metabolic data
% CHIPVARLIKEGAMMAGRAD gradient of chipVarLikeGamma
% CHIPVARLIKEGAMMA one dimensional gamma likelihood
% CHIPVARLIKEGRAD gradient of chipVarLike
% CHIPVARLIKELIHOODBOUND variational lower bound on marginal likelihood
% CHIPVARLIKELIHOODBOUNDMU variational lower bound on marginal likelihood
% CHIPVARLIKELIHOODCHECK Compute the difference in likelhoods.
% CHIPVARLIKELIHOODCHECKMU Compute the difference in likelhoods.
% CHIPVARLIKE likelihood for chipVar to optimise Gamma and m
% CHIPVAROPTIONS sets default options for chipVar
% CHIPVARREDLOADDATA loads reduced Spellman Data with Lee et al ChIP data.
% CHIPVARTULOADDATA loads metabolic Data with combined ChIP data.
% CHIPVARUPDATEALPHA updates alpha in E-M
% CHIPVARUPDATEBETA updates the precision in E-M algorithm
% CHIPVARUPDATEBETAMU updates the precision in E-M algorithm
% DEMFAKEVAR demonstrates chipVar on artificial data
% DEMSPELLMANVAR demonstrates chipVar on Spellman
