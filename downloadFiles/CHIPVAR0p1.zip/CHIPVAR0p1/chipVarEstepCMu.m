function expectationsC=chipVarEstepCMu(data,X,beta,Gamma, expectationsB,expectationsMu)
